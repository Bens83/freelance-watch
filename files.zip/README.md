# freelance-watch

Veille personnelle de missions freelance (email marketing, intégration HTML, newsletters).
Alertes **ntfy** (push instantané) + **email**.

```
Recherche web (posts LinkedIn publics + autres sites) + RSS
  → dédoublonnage → filtre mots-clés → tri IA (Claude) → ntfy + email
```

Le script ne se connecte pas à LinkedIn et n'utilise pas votre compte : il lit les résultats
de recherche web publics (via l'API Serper).

## Installation (≈ 20 min)

### 1. Les clés dont vous avez besoin

| Service | Rôle | Où |
|---|---|---|
| Serper | Recherche web | https://serper.dev (crédits gratuits à l'inscription) |
| Anthropic | Tri IA | https://console.anthropic.com |
| ntfy | Push mobile/navigateur | Application ntfy (iOS/Android) ou https://ntfy.sh |
| SMTP | Email | Gmail : activer la validation en 2 étapes, puis créer un **mot de passe d'application** |

**ntfy** : choisissez un nom de topic long et imprévisible (ex. `fw-k39x-p7q2-m81z`).
Sur ntfy.sh, le nom du topic fait office de mot de passe. Abonnez-vous à ce topic dans l'appli.

### 2. Test en local

```bash
pip install -r requirements.txt
cp .env.example .env        # puis remplissez-le
python main.py --test       # envoie une notification de test (ntfy + email)
python main.py --dry-run    # exécution complète, mais n'envoie rien et ne sauvegarde rien
```

### 3. Déploiement gratuit sur GitHub Actions

1. Créez un dépôt GitHub **privé** et poussez-y ce dossier.
2. *Settings → Secrets and variables → Actions* : ajoutez
   `SERPER_API_KEY`, `ANTHROPIC_API_KEY`, `NTFY_TOPIC`,
   `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `EMAIL_TO`.
3. Onglet *Actions* → *freelance-watch* → **Run workflow** pour un premier lancement manuel.
4. Ensuite, il tourne tout seul toutes les 2 h (modifiable dans `.github/workflows/watch.yml`).

L'état (posts déjà vus) est sauvegardé dans `state/seen.json` par un commit automatique,
pour ne jamais être alerté deux fois.

## Réglages

Tout se passe dans `config.yaml` :

- **`profile`** : votre description, utilisée par l'IA pour noter chaque annonce.
- **`sources.serp.queries`** : les recherches Google. Chaque requête consomme 1 crédit Serper par exécution.
- **`filters`** : mots-clés (sujet + intention) et mots exclus, avant l'IA.
- **`llm.min_relevance`** : seuil de score (0-100). Trop de bruit → augmentez ; rien ne remonte → baissez.
- **`notifications.email.mode`** : `instant` ou `daily` (digest à `digest_hour`).

## Réglage fin recommandé

1. Laissez tourner 3-4 jours avec `min_relevance: 40` pour voir ce qui remonte.
2. Ajoutez au `exclude` les mots qui reviennent dans les faux positifs.
3. Ajoutez à `topics` / aux requêtes les outils que vous maîtrisez (nom de vos ESP, par exemple).
4. Remontez le seuil à 55-65 quand le bruit est maîtrisé.

## Limites à connaître

- **Couverture partielle** : Google n'indexe pas tous les posts LinkedIn, et avec un délai
  (de quelques minutes à plusieurs heures). Ce n'est pas du temps réel strict.
- **Extraits courts** : l'IA juge sur l'extrait du résultat de recherche, pas sur le post complet.
  Ouvrez le lien pour les détails.
- **GitHub Actions** : les exécutions planifiées peuvent avoir quelques minutes de retard.
  Le workflow est désactivé automatiquement si le dépôt reste inactif 60 jours ; les commits d'état
  automatiques comptent comme activité, mais vérifiez de temps en temps l'onglet *Actions*.
- **Coût** : surtout les requêtes Serper (nombre de requêtes × exécutions par jour). Le tri IA
  coûte très peu car il ne s'applique qu'aux résultats ayant passé le filtre mots-clés.
